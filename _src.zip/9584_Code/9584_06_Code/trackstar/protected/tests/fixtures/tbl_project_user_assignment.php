<?php

return array(
	'user1ToProject1'=>array(
		'project_id' => 1,
		'user_id' => 1,
		'create_time' => '',
		'create_user_id' => '',
		'update_time' => '',
		'update_user_id' => '',
	),
	'user2ToProject1'=>array(
		'project_id' => 1,
		'user_id' => 2,
		'create_time' => '',
		'create_user_id' => '',
		'update_time' => '',
		'update_user_id' => '',
	),
);


