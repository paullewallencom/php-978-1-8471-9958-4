<?php

return array(
	'issueBug'=>array(
		'name' => 'Test Bug 1',
		'description' => 'This is test bug for project 1',
		'project_id' => 1,
		'type_id' => 0,
		'status_id' => 1,
		'owner_id' => 1,
		'requester_id' => 2,
		'create_time' => '',
		'create_user_id' => '',
		'update_time' => '',
		'update_user_id' => '',
	),
	'issueFeature'=>array(
		'name' => 'Test Feature 1',
		'description' => 'This is test feature for project 2',
		'project_id' => 2,
		'type_id' => 1,
		'status_id' => 0,
		'owner_id' => 2,
		'requester_id' => 1,
		'create_time' => '',
		'create_user_id' => '',
		'update_time' => '',
		'update_user_id' => '',
	),
);

