<?php

return array(
	'user1'=>array(
		'email' => 'test1@notanaddress.com',
		'username' => 'Test_User_One',
		'password' => MD5('test1'),
		'last_login_time' => '',
		'create_time' => '',
		'create_user_id' => '',
		'update_time' => '',
		'update_user_id' => '',
	),
	'user2'=>array(
		'email' => 'test2@notanaddress.com',
		'username' => 'Test_User_Two',
		'password' => MD5('test2'),
		'last_login_time' => '',
		'create_time' => '',
		'create_user_id' => '',
		'update_time' => '',
		'update_user_id' => '',
	),
);



